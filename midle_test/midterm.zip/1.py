x = input()
y = x // 3

print(y)


